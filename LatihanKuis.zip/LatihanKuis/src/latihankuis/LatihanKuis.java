package latihankuis;

public class LatihanKuis {

   
    public static void main(String[] args) {
        new LoginPage();
    }
    
}
